% ========================================================================
% Time-varying Graph Signal Reconstruction,
%
% Copyright(c) 2017 Kai Qiu and Yuantao Gu
% All Rights Reserved.
% ----------------------------------------------------------------------
% The dimension of PM2.5 Concentration dataset is 93x200, with the rows indicating 93 
% observation sites in California, and each column indicating one day. 
% 
% Version 1.0
% Written by Kai Qiu (q1987k@163.com)
%----------------------------------------------------------------------

clear; clc; close all;

%% run the methods
% natural neighbor interpolation
if ~exist('Error_NNI_RMSE.mat','file')
    Run_NNI
end

% low-rank matrix completion
if ~exist('Error_LowRank_RMSE.mat','file')
    Run_LowRank
end

% graph regularization
if ~exist('Error_gsmooth_RMSE.mat','file')
    Run_graph_regularization
end

% graph-time Tikhonov
if ~exist('Error_station_RMSE.mat','file')
    Run_graph_time_Tikhonov
end

% proposed online distributed method
if ~exist('Error_online_RMSE.mat','file')
    Run_proposed_online
end

% proposed batch method
if ~exist('Error_batch_RMSE.mat','file')
    Run_proposed_batch
end


%% plot
load Error_NNI_RMSE
Error_NNI_RMSE = mean(Error_RMSE);

load Error_LowRank_RMSE
Error_LowRank_RMSE = mean(Error_RMSE);

load Error_gsmooth_RMSE
Error_gsmooth_RMSE = mean(Error_RMSE);

load Error_station_RMSE
Error_station_RMSE = mean(Error_RMSE);

load Error_online_RMSE
Error_online_RMSE = mean(Error_RMSE);

load Error_batch_RMSE
Error_batch_RMSE = mean(Error_RMSE);

C = get(0,'defaultAxesColorOrder');
figure; hold on;
plot(rate_set,Error_NNI_RMSE, '-.x', 'color', C(6,:), 'linewidth', 2);
plot(rate_set,Error_LowRank_RMSE, '--o', 'color', C(3,:), 'linewidth', 2);
plot(rate_set,Error_gsmooth_RMSE, ':+', 'color', C(1,:), 'linewidth', 2);
plot(rate_set,Error_station_RMSE, '--d', 'color', C(5,:), 'linewidth', 2);
plot(rate_set,Error_online_RMSE, '-s', 'color', C(2,:), 'linewidth', 2);
plot(rate_set,Error_batch_RMSE, '-*', 'color', C(4,:), 'linewidth', 2);
xlabel('Sampling rate');ylabel('RMSE');box on;
h=legend('Natural neighbor interpolation', 'Low-rank matrix completion', ...
'Graph regularization', 'Graph-time Tikhonov', 'Proposed online distr. method', ...
'Proposed batch method', 'Location','NorthEast');
set(h,'fontsize',14);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',16); 
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',16); 
