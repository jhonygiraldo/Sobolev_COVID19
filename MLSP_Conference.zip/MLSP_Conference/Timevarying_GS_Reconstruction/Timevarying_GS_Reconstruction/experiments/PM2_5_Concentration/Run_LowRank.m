% comparison method: Low-rank matrix completion

clear; clc; close all;
addpath('../../solvers');
addpath('../../utilities');
load PM2_5_Concentration.mat
Temp = myDataPM(:,1:200);  % the time length is 200.
Temp(Temp<0)=0;
[N,T] = size(Temp);

SampleMatrix0 = (Temp~=0); % indicating the valid data

test_time = 50; % the sampling matrix is different at each time
rate_set = 0.1 : 0.05 : 0.45; % sampling rate
for i_rate = 1 : length(rate_set)
    i_rate
    for i_test = 1:test_time
        i_test
        SampleNum = floor(N*rate_set(i_rate)); % the number of sampled points at each time
        SampleMatrix = zeros(N,T); % sampling matrix
        for i = 1:T
            IndexMeasure = find(SampleMatrix0(:,i));
            IndexSelect = IndexMeasure(randperm(length(IndexMeasure), SampleNum));
            SampleMatrix(IndexSelect,i) = 1;
        end

        TempS = SampleMatrix(:,1:T) .* (Temp);

        %%
        n = N*T;
        k = 60; % estimated rank (the results are not senstive to k)
        dr = k*(N+T-k);
        m = sum(SampleMatrix(:));

        loc = find(SampleMatrix(:)~=0); % locations of sampled points
        y = TempS(loc); % sampled values
        sr = m/n; % sampling rate
        maxr = floor(((N+T)-sqrt((N+T)^2-4*m))/2);
        opts = get_opts_FPCA(TempS,maxr,N,T,sr,dr/m); % get the parameters
        Out = solver_FPCA_MatComp(N,T,loc,y,opts);
        x_recon = Out.x;

        tMatrix = Temp(SampleMatrix0>0) - x_recon(SampleMatrix0>0);
        Error_RMSE(i_test,i_rate) = norm(tMatrix(:))/sqrt(length(tMatrix)); %RMSE
    end
end

save Error_LowRank_RMSE Error_RMSE rate_set
