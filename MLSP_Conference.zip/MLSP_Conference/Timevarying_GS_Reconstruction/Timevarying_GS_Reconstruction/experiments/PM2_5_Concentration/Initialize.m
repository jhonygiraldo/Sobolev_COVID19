% ========================================================================
% Time-varying Graph Signal Reconstruction,
%
% Copyright(c) 2017 Kai Qiu and Yuantao Gu
% All Rights Reserved.
% ----------------------------------------------------------------------
% The dimension of PM2.5 Concentration dataset is 93x200, with the rows indicating 93 
% observation sites in California, and each column indicating one day. 
% 
% Version 1.0
% Written by Kai Qiu (q1987k@163.com)
%----------------------------------------------------------------------

clear; clc; close all;
addpath('../../utilities');

%% graph construction
load PM2_5_Concentration.mat
N = size(myDataPM,1);
Dist = zeros(N);
for i = 1:N % distances between each two points
    for j = i+1:N
        Dist(i,j)=distance(Position(i,1),Position(i,2),Position(j,1),Position(j,2));
        Dist(j,i)=Dist(i,j);
    end
end
A=zeros(N); % Adjacency matrix
W=zeros(N); % Weighted matrix
k=5; % k-NN method
for i=1:N
    [sortd,ind]=sort(Dist(i,:),'ascend');
    A(i,ind(2:k+1))=1;
    A(ind(2:k+1),i)=1;
    W(i,ind(2:k+1))=1./(Dist(i,ind(2:k+1))).^2;
    W(ind(2:k+1),i)=W(i,ind(2:k+1));
end
W=W/max(max(W));
D=diag(sum(W));
L=D-W;
save paramAWD A W D L


%% plot the graph
load PM2_5_Concentration.mat
load paramAWD
C = linspecer(7);
figure; hold on;
worldmap([32 42], [-125 -115]);
mlabel('south'); plabel('west');
load coast
geoshow(lat, long,'Color', 'black')
plotm([Position(:,1) Position(:,2)],'o', 'color', C(4,:), 'Markerfacecolor', C(4,:),'Markersize', 5);
[ki,kj]=find(A);
plotm([Position(ki,1)';Position(kj,1)'],[Position(ki,2)';Position(kj,2)'],'Color',C(2,:));
    