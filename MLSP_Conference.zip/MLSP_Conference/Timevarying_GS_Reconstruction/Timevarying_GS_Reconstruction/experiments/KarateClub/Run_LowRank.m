% comparison method: Low-rank matrix completion

clear; clc; close all;
addpath('../../solvers');
addpath('../../utilities');
load paramAWD
[N,T] = size(Temp);


test_time = 50; % the sampling matrix is different at each time
rate_set = 0.1 : 0.1 : 0.9; % sampling rate
for i_rate = 1 : length(rate_set)
    i_rate
    for i_test = 1:test_time
        i_test
        SampleNum = floor(N*rate_set(i_rate)); % the number of sampled points at each time
        SampleMatrix = zeros(N,T); % sampling matrix
        for i = 1:T
            SampleMatrix(randperm(N, SampleNum),i) = 1;
        end

        TempS = SampleMatrix(:,1:T) .* (Temp+noise);

        %%
        n = N*T;
        k = 16; % estimated rank (the results are not senstive to k)
        dr = k*(N+T-k);
        m = sum(SampleMatrix(:));

        loc = find(SampleMatrix(:)~=0); % locations of sampled points
        y = TempS(loc); % sampled values
        sr = m/n; % sampling rate
        maxr = floor(((N+T)-sqrt((N+T)^2-4*m))/2);
        opts = get_opts_FPCA(TempS,maxr,N,T,sr,dr/m); % get the parameters
        Out = solver_FPCA_MatComp(N,T,loc,y,opts);
        x_recon = Out.x;

        Error_RMSE(i_test,i_rate) = norm(Temp(:) - x_recon(:))/sqrt(N*T); %RMSE
    end
end

save Error_LowRank_RMSE Error_RMSE rate_set
