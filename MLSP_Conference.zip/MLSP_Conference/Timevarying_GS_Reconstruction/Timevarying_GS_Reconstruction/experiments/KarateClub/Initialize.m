% ========================================================================
% Time-varying Graph Signal Reconstruction,
%
% Copyright(c) 2017 Kai Qiu and Yuantao Gu
% All Rights Reserved.
% ----------------------------------------------------------------------
% The social network of Zachary��s karate club: 34 nodes and 78 undirected edges.
% The dimension of social network dataset is 34x200. 
% 
% Version 1.0
% Written by Kai Qiu (q1987k@163.com)
%----------------------------------------------------------------------

clear; clc; close all;

%% graph construction
N = 34;
W=zeros(N);
W(1,:) = [0 4 5 3, 3 3 3 2, 2 0 2 3, 2 3 0 0, 0 2 0 2, 0 2 0 0, 0 0 0 0, 0 0 0 2, 0 0];
W(:,1) = W(1,:)';
W(2,:) = [4 0 6 3, 0 0 0 4, 0 0 0 0, 0 5 0 0, 0 1 0 2, 0 2 0 0, 0 0 0 0, 0 0 2 0, 0 0];
W(3,:) = [5 6 0 3, 0 0 0 4, 5 1 0 0, 0 3 0 0, 0 0 0 0, 0 0 0 0, 0 0 0 2, 2 0 0 0, 3 0];
W(4,1:3) = [3 3 3]; W(4,8) = 3; W(4,13:14) = [3 3];
W(5,7) = 2; W(5,11) = 3;
W(6,7) = 5; W(6,11) = 3; W(6,17) = 3; 
W(7,5:6) = [2 5]; W(7,17) = 3; 
W(8,2:4) = [4 4 3]; 
W(9,3) = 5; W(9,31:34) = [3 0 4 3]; 
W(10,3) = 1; W(10,34) = 2;
W(11,5:6) = [3 3];
W(13,4) = 3; 
W(14,2:4) = [5 3 3]; W(14,34) = 3; 
W(15,33:34) = [3 2]; 
W(16,33:34) = [3 4]; 
W(17,6:7) = [3 3]; 
W(18,2) = 1; 
W(19,33:34) = [1 2]; 
W(20,2) = 2; W(20,34) = 1; 
W(21,33:34) = [3 1];
W(22,2) = 2;
W(23,33) = 2;
W(24,26:34) = [5 0 4 0 2 0 0 5 4];
W(25,26:32) = [2 0 3 0 0 0 2];
W(26,24:32) = [5 2 0 0 0 0 0 0 7];
W(27,30:34) = [4 0 0 0 2];
W(28,3) = 2; W(28,24:34) = [4 3 0 0 0 0 0 0 0 0 4];
W(29,3) = 2; W(29,32:34) = [2 0 2];
W(30,24:34) = [2 0 0 4 0 0 0 0 0 3 2];
W(31,2) = 2; W(31,9) = 3; W(31,33:34) = [3 3];
W(32,25:34) = [2 7 0 0 2 0 0 0 4 4];
W(33,:) = [0 0 3 0, 0 0 0 0, 4 0 0 0, 0 0 3 3, 0 0 1 0, 3 0 2 5, 0 0 0 0, 0 3 3 4, 0 5];
W(34,:) = [0 0 0 0, 0 0 0 0, 3 2 0 0, 0 3 2 4, 0 0 2 1, 1 0 0 4, 0 0 2 4, 2 2 3 4, 5 0];

W=W/max(max(W)); 
D=diag(sum(W));
L=D-W;    

% generate the time-varying graph signal
[V,Lambda]=eig(L);
Lambda(1,1)=0;
lambda = diag(Lambda);
lambdaHalfInv = 1./sqrt(lambda);
lambdaHalfInv(1) = 0;
LHalfInv = V*diag(lambdaHalfInv)*V';

T = 200;
Temp = zeros(N, T);
ftmp = V'* randn(N,1);
ftmp(4:end) = ftmp(4:end)/10; % Weakened the high frequency components
ftmp = V*ftmp;
Temp(:,1) = ftmp / norm(ftmp) * 100;

epsilon = 1; % smoothness level
for k = 2:T
    f = randn(N,1);
    f = f / norm(f) * epsilon;
    fdc = randn * 0.15 * ones(N,1); % DC component
    Temp(:,k) = Temp(:,k-1) + LHalfInv*f + fdc;
end

noise = 0.1 * randn(size(Temp)); % measurement noise
save paramAWD W D L Temp noise
    