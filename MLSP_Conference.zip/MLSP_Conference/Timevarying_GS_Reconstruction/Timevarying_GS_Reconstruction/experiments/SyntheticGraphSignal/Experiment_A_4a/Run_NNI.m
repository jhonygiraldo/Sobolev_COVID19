% comparison method: Natural neighbor interpolation

clear; clc; close all;
addpath('../../../solvers');
load ../paramAWD
[N,T] = size(Temp);


test_time = 50; % the sampling matrix is different at each time
for i_test = 1 : test_time
    i_test       
    SampleNum = floor(N*0.4); % the number of sampled points at each time
    SampleMatrix = zeros(N,T); % sampling matrix
    for i = 1:T
        SampleMatrix(randperm(N, SampleNum),i) = 1;
    end

    TempS = SampleMatrix(:,1:T) .* (Temp+noise); % sampled data

    %% interpolated by function scatteredInterpolant
    x_recon = solver_NNI(SampleMatrix, TempS, Position);

    tMatrix = Temp - x_recon;
    Error_RMSE(i_test, :) = sqrt(diag(tMatrix' * tMatrix))/sqrt(N); %RMSE
end

save Error_NNI_RMSE Error_RMSE
