% ========================================================================
% Time-varying Graph Signal Reconstruction,
%
% Copyright(c) 2017 Kai Qiu and Yuantao Gu
% All Rights Reserved.
% ----------------------------------------------------------------------
% 100 points are generated randomly.
% The dimension of the synthetic dataset is 100x600. 
% 
% Version 1.0
% Written by Kai Qiu (q1987k@163.com)
%----------------------------------------------------------------------

clear; clc; close all;

%% run the methods
% natural neighbor interpolation
if ~exist('Error_NNI_RMSE.mat','file')
    Run_NNI
end

% low-rank matrix completion
if ~exist('Error_LowRank_RMSE.mat','file')
    Run_LowRank
end

% graph regularization
if ~exist('Error_gsmooth_RMSE.mat','file')
    Run_graph_regularization
end

% graph-time Tikhonov
if ~exist('Error_station_RMSE.mat','file')
    Run_graph_time_Tikhonov
end

% proposed online distributed method
if ~exist('Error_online_RMSE.mat','file')
    Run_proposed_online
end

% proposed batch method
if ~exist('Error_batch_RMSE.mat','file')
    Run_proposed_batch
end


%% plot
load Error_NNI_RMSE
Error_NNI_RMSE = Error_RMSE;

load Error_LowRank_RMSE
Error_LowRank_RMSE = Error_RMSE;

load Error_gsmooth_RMSE
Error_gsmooth_RMSE = Error_RMSE;

load Error_station_RMSE
Error_station_RMSE = Error_RMSE;

load Error_online_RMSE
Error_online_RMSE = Error_RMSE;

load Error_batch_RMSE
Error_batch_RMSE = Error_RMSE;

load paramAWD;
[N,T] = size(Temp);
noise_set2 = -20*log10(noise_set* sqrt(N*T) ./ norm(Temp));
Error_NNI_RMSE2 = -20*log10(Error_NNI_RMSE * sqrt(N*T) ./ norm(Temp));
Error_LowRank_RMSE2 = -20*log10(Error_LowRank_RMSE * sqrt(N*T) ./ norm(Temp));
Error_gsmooth_RMSE2 = -20*log10(Error_gsmooth_RMSE * sqrt(N*T) ./ norm(Temp));
Error_station_RMSE2 = -20*log10(Error_station_RMSE * sqrt(N*T) ./ norm(Temp));
Error_online_RMSE2 = -20*log10(Error_online_RMSE * sqrt(N*T) ./ norm(Temp));
Error_batch_RMSE2 = -20*log10(Error_batch_RMSE * sqrt(N*T) ./ norm(Temp));

C = get(0,'defaultAxesColorOrder');
figure; semilogy(noise_set2,Error_NNI_RMSE2, '-.x', 'color', C(6,:), 'linewidth', 2);
hold on;semilogy(noise_set2,Error_LowRank_RMSE2, '--o', 'color', C(3,:), 'linewidth', 2);
hold on;semilogy(noise_set2,Error_gsmooth_RMSE2, ':+', 'color', C(1,:), 'linewidth', 2);
hold on;semilogy(noise_set2,Error_station_RMSE2, '--d', 'color', C(5,:), 'linewidth', 2);
hold on;semilogy(noise_set2,Error_online_RMSE2, '-s', 'color', C(2,:), 'linewidth', 2);
hold on;semilogy(noise_set2,Error_batch_RMSE2, '-*', 'color', C(4,:), 'linewidth', 2);
xlabel('Input SNR (dB)','Interpreter','latex');ylabel('Output SNR (dB)');box on;
h=legend('Natural neighbor interpolation', 'Low-rank matrix completion', ...
'Graph regularization', 'Graph-time Tikhonov', 'Proposed online distr. method', ...
'Proposed batch method', 'Location','NorthEast');
set(h,'fontsize',14);
h_xlabel = get(gca,'XLabel');
set(h_xlabel,'FontSize',16); 
h_xlabel = get(gca,'YLabel');
set(h_xlabel,'FontSize',16); 
ylim([5 35]);
