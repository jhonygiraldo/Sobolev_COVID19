========================================================================================================
* The code is for the methods described in

Kai Qiu, Xianghui Mao, Xinyue Shen, Xiaohan Wang, Tiejian Li, and Yuantao Gu,
"Time-varying Graph Signal Reconstruction",
IEEE Journal of Selected Topics in Signal Processing, Special Issue on Graph Signal Processing, 2017. 
Version 1.0
Copyright(c) 2017 Kai Qiu and Yuantao Gu
All Rights Reserved.

========================================================================================================
* Experiment List
1. SyntheticGraphSignal
Experiments on the synthetic Graphs and signals, corresponding to Section VI.A of the paper. 
Wherein, Experiment_A_4a and Experiment_A_4b are corresponding to Fig. 4(a) and (b) respectively; 
Experiment_A_5a and Experiment_A_5b are corresponding to Fig. 5(a) and (b) respectively.

2. KarateClub
Experiment on the social network of Zachary��s karate club, corresponding to Section VI.B. 

3. SeaSurfaceTemperature
Experiment on the sea surface temperature, corresponding to Section VI.C. 

4. SeaLevelPressure
Experiment on the global sea-level pressure, corresponding to Section VI.D. 

5. PM2_5_Concentration
Experiment on the daily mean PM2.5 concentration of California, corresponding to Section VI.E. 

---------------------------------------------------------------------------------------------------------
For each experiment, run Initialize.m first to construct the graph or generate simulation signals.
Then run Run_all.m to test all the methods in the paper and plot the final figure. 

========================================================================================================
For any problems with the code, please contact us: q1987k@163.com, gyt@tsinghua.edu.cn

