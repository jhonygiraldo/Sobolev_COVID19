clear all, close all, clc;
%%
load('error_batch_random.mat');
load('m.mat');
%%
line_width = 1.5;
marker_size = 6;
font_size = 21;
width = 680;
heigth = 360;
path_figures = 'figures_exp_1/';
mkdir(path_figures);
%% iterations
figure()
semilogy(m,mean(repetitions_qui),'ro--','LineWidth',line_width,'MarkerSize',marker_size);
hold on;
semilogy(m,mean(repetitions_sobolev),'bs-','LineWidth',line_width,'MarkerSize',marker_size);
ylabel('Iterations','Interpreter','Latex');
xlabel('Sampling density','Interpreter','Latex');
xlim([m(1) m(end)]);
lgd = legend({'Qiu method','Sobolev reconstruction'},'Location','northeast');
set(lgd,'Interpreter','latex');
set(lgd,'color','none');
set(lgd,'Box','off');
title('COVID-19 USA New Cases','Interpreter','Latex');
get(gca);
set(gca,'FontName','times','FontSize',font_size,'TickLabelInterpreter','Latex');
set(gcf,'Position',[100,100,width,heigth]);
saveas(gcf,[path_figures 'iterations.png']);
saveas(gcf,[path_figures 'iterations.svg']);