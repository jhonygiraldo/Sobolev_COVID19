clear all, close all, clc;
%%
load('error_qui_batch_random.mat');
load('error_sobolev_batch_random.mat');
load('error_NNI_random.mat');
load('m.mat');
%%
line_width = 1.5;
marker_size = 6;
font_size = 21;
width = 680;
heigth = 360;
path_figures = 'figures_exp_1/';
mkdir(path_figures);
%%
plot(m,mean(error_matrix_qui_batch_random),'ro--','LineWidth',line_width,'MarkerSize',marker_size);
hold on;
%semilogy(m,mean(error_matrix_NNI_random),'k*-','LineWidth',line_width,'MarkerSize',marker_size);
plot(m,mean(error_matrix_sobolev_batch_random),'bs-','LineWidth',line_width,'MarkerSize',marker_size);
ylabel('Mean Square Error','Interpreter','Latex');
xlabel('Sampling density','Interpreter','Latex');
xlim([m(1) m(end)]);
lgd = legend({'Qiu method','Sobolev reconstruction'},'Location','northeast');
%lgd = legend({'Qui algorithm','Tikhonov','Sobolev norm minimization'},'Location','northeast');
set(lgd,'Interpreter','latex');
set(lgd,'color','none');
set(lgd,'Box','off');
title('COVID-19 USA New Cases','Interpreter','Latex');
get(gca);
set(gca,'FontName','times','FontSize',font_size,'TickLabelInterpreter','Latex');
set(gcf,'Position',[100,100,width,heigth]);
saveas(gcf,[path_figures 'covid_19_experiment.png']);
saveas(gcf,[path_figures 'covid_19_experiment.svg']);