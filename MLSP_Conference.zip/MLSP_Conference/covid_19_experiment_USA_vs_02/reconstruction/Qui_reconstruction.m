clear all, close all, clc;
%%
addpath('/home/jhonygiraldoz/time_varying_graph_signals/Timevarying_GS_Reconstruction/Timevarying_GS_Reconstruction/solvers'); % Path to solvers of Qui
%%
load('../graph_construction/full_graph.mat');
load('../covid_19_cases.mat');
x_matrix = Data;
%%
m = [0.5:0.1:0.9, 0.99, 0.995];  %Sampling density
signals_t = size(x_matrix,2);
%% alpha parameter
alpha_set = [1e-3, 1e-2, 2e-2, 5e-2, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 1e2, 2e2, 5e2];
error_qui_random = cell(1,length(alpha_set));
%%
param1.L = G.L; % Graph Laplacian
param1.niter = 5000;
%%
repetitions = 5;
for ii=0:repetitions-1
    ii
    for i=1:length(m)
        num_samples = round(m(i)*G.N);
        %% Parameters higher reg
        x_reconstructed_qui_random = cell(1,length(alpha_set));
        %% Random sampling
        random_pattern = zeros(signals_t,G.N);
        for j=1:signals_t
            random_pattern(j,randperm(G.N,num_samples)) = 1;
        end
        for j=1:signals_t
            %%
            x_current = x_matrix(:,j);
            %%
            indx_non_sampled = find(random_pattern(j,:) == 0);
            %% Qui reconstruction
            for k=1:length(alpha_set)
                param1.alpha = alpha_set(k);
                param1.J = random_pattern(j,:)';
                param1.y = x_current.*param1.J;
                if(j > 1)
                    param1.x0 = x_reconstructed_qui_random{1,k}(:,j-1);
                    param1.ref = x_reconstructed_qui_random{1,k}(:,j-1);
                else
                    param1.x0 = param1.y; % the reference signal is the sampled signal for j=1.
                    param1.ref = zeros(G.N,1);
                end
                x_reconstructed_qui_random{1,k}(:,j) = solver_OR_TVGS(param1);
                error_qui_random{1,k}((ii*signals_t)+j,i) = immse(x_current(indx_non_sampled),x_reconstructed_qui_random{1,k}(indx_non_sampled,j));
            end
        end
    end
end
results_path = '../results/';
mkdir(results_path);
save([results_path 'error_qui_random.mat'],'error_qui_random');
%%
save([results_path 'm.mat'],'m');
save([results_path 'qui_parameter.mat'],'alpha_set');