clear all, close all, clc;
%%
addpath('/home/jhonygiraldoz/time_varying_graph_signals/Timevarying_GS_Reconstruction/Timevarying_GS_Reconstruction/solvers'); % Path to solvers of Qui
addpath('/home/jhonygiraldoz/time_varying_graph_signals/Timevarying_GS_Reconstruction/Timevarying_GS_Reconstruction/utilities');
%%
load('../graph_construction/full_graph.mat');
load('../covid_19_cases.mat');
x_matrix = Data;
%%
m = [0.5:0.1:0.9, 0.995];  %Sampling density
signals_t = size(x_matrix,2);
%% alpha parameter
alpha_set = [1e-3, 1e-2, 2e-2, 5e-2, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 1e2, 2e2, 5e2];
beta_set = [1e-3, 1e-2, 2e-2, 5e-2, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 1e2, 2e2, 5e2];
error_tikhonov_random = cell(length(beta_set),length(alpha_set));
%%
param.niter = 20000;
param.gamma = 0;
param.L = G.L; % Laplacian
%%
repetitions = 5;
for ii=0:repetitions-1
    ii
    for i=1:length(m)
        num_samples = round(m(i)*G.N);
        %% Random sampling
        random_pattern = zeros(signals_t,G.N);
        for j=1:signals_t
            random_pattern(j,randperm(G.N,num_samples)) = 1;
        end
        SampleMatrix = random_pattern';
        param.J = SampleMatrix; % sampling matrix
        param.y = param.J.*(x_matrix); % sampled data
        param.T = TV_Temp(); % temporal difference operator 
        for jj=1:length(beta_set)
            param.beta = beta_set(jj);
            for j=1:length(alpha_set)
                param.alpha = alpha_set(j);
                param.x0 = 0 * param.y;
                x_recon = solver_BR_TVGS(param);
                for k=1:size(x_recon,2)
                    indx_non_sampled = find(SampleMatrix(:,k) == 0);
                    error_tikhonov_random{jj,j}((ii*signals_t)+k,i) = immse(x_matrix(indx_non_sampled,k),x_recon(indx_non_sampled,k));
                end
            end
        end
    end
end
%% Best parameters
mean_errors_tikhonov = zeros(size(error_tikhonov_random));
for i=1:size(error_tikhonov_random,1)
    for j=1:size(error_tikhonov_random,2)
        mean_errors_tikhonov(i,j) = mean(mean(error_tikhonov_random{i,j}));
    end
end
[best_beta, best_alpha] = find(mean_errors_tikhonov == min(min(mean_errors_tikhonov)));
%% Experiment best parameters
repetitions = 100;
error_matrix_tikhonov_random = zeros(repetitions*signals_t,length(m));
param.alpha = alpha_set(best_alpha);
param.beta = beta_set(best_beta);
param.L = G.L; % Laplacian
for ii=0:repetitions-1
    ii
    for i=1:length(m)
        num_samples = round(m(i)*G.N);
        %% Random sampling
        random_pattern = zeros(signals_t,G.N);
        for j=1:signals_t
            random_pattern(j,randperm(G.N,num_samples)) = 1;
        end
        SampleMatrix = random_pattern';
        param.J = SampleMatrix; % sampling matrix
        param.y = param.J.*(x_matrix); % sampled data
        param.T = TV_Temp(); % temporal difference operator 
        param.x0 = 0 * param.y;
        x_recon = solver_BR_TVGS(param);
        for k=1:size(x_recon,2)
            indx_non_sampled = find(SampleMatrix(:,k) == 0);
            error_matrix_tikhonov_random((ii*signals_t)+k,i) = immse(x_matrix(indx_non_sampled,k),x_recon(indx_non_sampled,k));
        end
    end
end
%%
results_path = '../results/';
mkdir(results_path);
save([results_path 'error_tikhonov_random.mat'],'error_tikhonov_random','error_matrix_tikhonov_random');
%%
save([results_path 'm.mat'],'m');
save([results_path 'tikhonov_parameter.mat'],'alpha_set','beta_set');