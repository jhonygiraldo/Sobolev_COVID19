clear all, close all, clc;
%%
load('../graph_construction/full_graph.mat');
load('../covid_19_cases.mat');
x_matrix = Data;
%%
m = [0.5:0.1:0.9, 0.99, 0.995];  %Sampling density
signals_t = size(x_matrix,2);
%% beta parameter
beta_parameter = [1:8];
epsilon_set = [1e-3, 1e-2, 2e-2, 5e-2, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 1e2, 2e2, 5e2];
error_sobolev_random = cell(length(beta_parameter),length(epsilon_set));
%% 
sobolev_term_matrices = cell(length(beta_parameter),length(epsilon_set));
for i=1:length(epsilon_set)
    inv_laplacian = inv(G.L+epsilon_set(i)*eye(G.N));
    for j=1:length(beta_parameter)
        sobolev_term = inv_laplacian^beta_parameter(j);
        %% Symmetrization
        sobolev_term = 0.5*(sobolev_term+sobolev_term.');
        sobolev_term_matrices{j,i} = sobolev_term;
    end
end
%%
repetitions = 5;
for ii=0:repetitions-1
    for i=1:length(m)
        i
        num_samples = round(m(i)*G.N);
        %% Parameters higher reg
        x_reconstructed_sobolev_random = cell(length(beta_parameter),length(epsilon_set));
        %% Random sampling
        random_pattern = zeros(signals_t,G.N);
        for j=1:signals_t
            random_pattern(j,randperm(G.N,num_samples)) = 1;
        end
        for j=1:signals_t
            %%
            M_random = zeros(num_samples,G.N);
            %%
            ind_M_random = 1;
            for k=1:G.N
                if random_pattern(j,k)
                    M_random(ind_M_random,k) = 1;
                    ind_M_random = ind_M_random + 1;
                end
            end
            x_current = x_matrix(:,j);
            %%
            x_sampled_random = M_random*x_current;
            indx_non_sampled = find(random_pattern(j,:) == 0);
            %% Sobolev minimization reconstruction
            for k=1:length(beta_parameter)
                for l=1:length(epsilon_set)
                    if(j > 1)
                        z_t_1_random = x_reconstructed_sobolev_random{k,l}(:,j-1);
                    else
                        z_t_1_random = zeros(G.N,1);
                    end
                    x_reconstructed_sobolev_random{k,l}(:,j) = z_t_1_random - (sobolev_term_matrices{k,l}*...
                        M_random'*inv(M_random*sobolev_term_matrices{k,l}*M_random')*(M_random*z_t_1_random-x_sampled_random));
                    error_sobolev_random{k,l}((ii*signals_t)+j,i) = immse(x_current(indx_non_sampled),x_reconstructed_sobolev_random{k,l}(indx_non_sampled,j));
                end
            end
        end
    end
end
results_path = '../results/';
mkdir(results_path);
save([results_path 'error_sobolev_random.mat'],'error_sobolev_random');
%%
save([results_path 'm.mat'],'m');
save([results_path 'sobolev_parameter.mat'],'beta_parameter','epsilon_set');