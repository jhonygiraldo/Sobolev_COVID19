clear all, close all, clc;
%%
addpath('/home/jhonygiraldoz/time_varying_graph_signals/Timevarying_GS_Reconstruction/Timevarying_GS_Reconstruction/solvers'); % Path to solvers of Qui
addpath('/home/jhonygiraldoz/time_varying_graph_signals/Timevarying_GS_Reconstruction/Timevarying_GS_Reconstruction/utilities');
%%
load('../graph_construction/full_graph.mat');
load('../sea_surface_temperature.mat');
x_matrix = Data(:,1:200);
%%
m = [0.1:0.1:0.9];  %Sampling density
signals_t = size(x_matrix,2);
%% Experiments
repetitions = 100;
error_matrix_NNI_random = zeros(repetitions*signals_t,length(m));
for ii=0:repetitions-1
    ii
    for i=1:length(m)
        num_samples = round(m(i)*G.N);
        %% Random sampling
        random_pattern = zeros(signals_t,G.N);
        for j=1:signals_t
            random_pattern(j,randperm(G.N,num_samples)) = 1;
        end
        SampleMatrix = random_pattern';
        J = SampleMatrix;
        Y = J.*(x_matrix);
        x_recon = solver_NNI(J, Y, Position);
        for k=1:size(x_recon,2)
            indx_non_sampled = find(SampleMatrix(:,k) == 0);
            error_matrix_NNI_random((ii*signals_t)+k,i) = immse(x_matrix(indx_non_sampled,k),x_recon(indx_non_sampled,k));
        end
    end
end
%%
results_path = '../results/';
mkdir(results_path);
save([results_path 'error_NNI_random.mat'],'error_matrix_NNI_random');
%%
save([results_path 'm.mat'],'m');